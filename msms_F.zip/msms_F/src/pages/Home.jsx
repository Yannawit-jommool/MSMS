import React from "react";

export default function Home() {
  return (
    <main className="content">
      {/* หัวข้อกลางหน้า */}
      <div className="page-header">
        <div className="page-title-box">ชื่อและตำแหน่ง</div>
      </div>

      {/* ตารางกิจกรรม */}
      <div className="activity-section">
        <div className="activity-title">กิจกรรม</div>

        <div className="activity-card">
          {/* Header ตาราง */}
          <div className="activity-header">
            <div>วันที่</div>
            <div>เวลา</div>
            <div className="activity-col">
              กิจกรรม
              <button className="add-activity-btn">＋</button>
            </div>
          </div>

          {/* แถวข้อมูล */}
          <div className="activity-row">
            <div>XXXX</div>
            <div>XXXXXXXXXX</div>
            <div>XXXXXXXXXX</div>
          </div>
        </div>
      </div>
    </main>
  );
}
