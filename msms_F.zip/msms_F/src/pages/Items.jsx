return (
  <main className="content">

    {/* ===== Header ===== */}
    <div className="page-header">
      <div className="page-title-box">รายการครุภัณฑ์</div>
    </div>

    {/* ===== Section ===== */}
    <section className="activity-section">

      <div className="activity-card">

        {/* ===== Table Header ===== */}
        <div className="activity-header">
          <div>ลำดับ</div>
          <div>ชื่อ</div>
          <div className="activity-col">
            <span>กิจกรรม</span>
          </div>
        </div>

        {/* ===== Rows ===== */}
        {items.map((it, index) => (
          <div className="activity-row" key={it._id}>
            <div>{index + 1}</div>
            <div>{it.name}</div>

            <div className="activity-col">
              {it.remaining > 0 ? (
                <button
                  className="borrow-btn"
                  onClick={() => openPopup(it)}
                >
                  ยืม
                </button>
              ) : (
                <span className="status borrowed">ไม่ว่าง</span>
              )}
            </div>
          </div>
        ))}

      </div>
    </section>

    {/* ===== Popup ===== */}
    {popupItem && (
      <div className="popup-overlay">
        <div className="popup-card">
          <form onSubmit={handleSubmit}>
            <h2>{popupItem.name}</h2>

            <label>Student ID</label>
            <input value={formData.studentId} disabled />

            <label>Name</label>
            <input
              value={formData.studentName}
              onChange={e => setFormData({ ...formData, studentName: e.target.value })}
            />

            <label>Borrow Date</label>
            <input type="date" value={formData.borrowDate} />

            <label>Return Date</label>
            <input type="date" value={formData.returnDate} />

            <div className="popup-actions">
              <button className="submit-btn">ยืนยัน</button>
              <button
                type="button"
                className="return-btn"
                onClick={() => setPopupItem(null)}
              >
                ยกเลิก
              </button>
            </div>
          </form>
        </div>
      </div>
    )}

  </main>
);
