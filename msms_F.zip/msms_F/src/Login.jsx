import React, { useState } from "react";
import "./Login.css";

export default function Login() {
  const [idNumber, setIdNumber] = useState("");
  const [nationalId, setNationalId] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!idNumber || !nationalId) {
      alert("กรุณากรอกข้อมูลให้ครบ");
      return;
    }

    console.log({ idNumber, nationalId });
    alert("กำลังตรวจสอบข้อมูล...");
  };

  return (
    <div className="login-page">
      <div className="login-card">
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>
              ID number <span className="required">*</span>
            </label>
            <input
              type="text"
              inputMode="numeric"
              pattern="[0-9]*"
              placeholder="Enter your ID number"
              value={idNumber}
              onChange={(e) =>
                setIdNumber(e.target.value.replace(/\D/g, ""))
              }
            />
          </div>

          <div className="form-group">
            <label>
              National ID number <span className="required">*</span>
            </label>
            <input
              type="text"
              inputMode="numeric"
              pattern="[0-9]*"
              placeholder="Enter your National ID number"
              value={nationalId}
              onChange={(e) =>
                setNationalId(e.target.value.replace(/\D/g, ""))
              }
            />
          </div>

          <button type="submit" className="btn-submit">
            เข้าสู่ระบบ
          </button>
        </form>
      </div>
    </div>
  );
}
